package vn.iotstar.util;

import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

import jakarta.servlet.http.Part;

public final class ValidationUtil {

    private ValidationUtil() {}

    public static final Pattern USERNAME = Pattern.compile("^[A-Za-z0-9_]{4,30}$");
    public static final Pattern EMAIL = Pattern.compile("^[\\w.+-]+@[\\w-]+(\\.[\\w-]+)*\\.[A-Za-z]{2,}$");
    public static final Pattern PHONE = Pattern.compile("^(0|\\+84)[0-9]{9}$");
    public static final Pattern FULLNAME = Pattern.compile("^[\\p{L}][\\p{L} .'-]{1,49}$");
    public static final Pattern OTP = Pattern.compile("^[0-9]{6}$");
    public static final Pattern VIDEO_ID = Pattern.compile("^[A-Za-z0-9_-]{3,20}$");

    public static final int PASSWORD_MIN = 6;
    public static final int PASSWORD_MAX = 50;

    public static final List<String> IMAGE_EXT = Arrays.asList("jpg", "jpeg", "png", "gif", "webp");
    public static final List<String> MEDIA_EXT = Arrays.asList("mp4", "webm", "ogg", "mov",
            "jpg", "jpeg", "png", "gif", "webp");

    public static boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }

    public static String trim(String s) {
        return s == null ? "" : s.trim();
    }

    public static boolean isValidUsername(String s) {
        return !isBlank(s) && USERNAME.matcher(s.trim()).matches();
    }

    public static boolean isValidEmail(String s) {
        return !isBlank(s) && s.trim().length() <= 100 && EMAIL.matcher(s.trim()).matches();
    }

    public static boolean isValidPhone(String s) {
        return !isBlank(s) && PHONE.matcher(s.trim()).matches();
    }

    public static boolean isValidFullname(String s) {
        return !isBlank(s) && FULLNAME.matcher(s.trim()).matches();
    }

    public static boolean isValidPassword(String s) {
        return s != null && !s.contains(" ") && s.length() >= PASSWORD_MIN && s.length() <= PASSWORD_MAX;
    }

    public static boolean isValidOtp(String s) {
        return !isBlank(s) && OTP.matcher(s.trim()).matches();
    }

    public static boolean isValidVideoId(String s) {
        return !isBlank(s) && VIDEO_ID.matcher(s.trim()).matches();
    }

    public static boolean lengthBetween(String s, int min, int max) {
        int len = trim(s).length();
        return len >= min && len <= max;
    }

    public static boolean isInteger(String s) {
        if (isBlank(s)) return false;
        try {
            Integer.parseInt(s.trim());
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static boolean hasFile(Part part) {
        return part != null && part.getSize() > 0
                && part.getSubmittedFileName() != null && !part.getSubmittedFileName().isBlank();
    }

    public static String fileName(Part part) {
        return Paths.get(part.getSubmittedFileName()).getFileName().toString();
    }

    public static String extension(String filename) {
        int i = filename.lastIndexOf('.');
        return i < 0 ? "" : filename.substring(i + 1).toLowerCase(Locale.ROOT);
    }

    public static boolean hasAllowedExtension(Part part, List<String> allowed) {
        return allowed.contains(extension(fileName(part)));
    }
}