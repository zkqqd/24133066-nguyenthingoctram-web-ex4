package vn.iotstar.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import vn.iotstar.service.UserService;
import vn.iotstar.service.impl.UserServiceImpl;
import vn.iotstar.util.ValidationUtil;

@SuppressWarnings("serial")
@WebServlet(urlPatterns = "/reset-password")
public class ResetPasswordController extends HttpServlet {
    UserService userService = new UserServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("reset_otp") == null) {
            resp.sendRedirect(req.getContextPath() + "/forgot-password");
            return;
        }
        req.getRequestDispatcher("/views/reset-password.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        resp.setCharacterEncoding("UTF-8");
        req.setCharacterEncoding("UTF-8");

        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("reset_otp") == null || session.getAttribute("reset_email") == null) {
            resp.sendRedirect(req.getContextPath() + "/forgot-password");
            return;
        }

        String inputOtp = req.getParameter("otp");
        String newPassword = req.getParameter("password");
        String confirmPassword = req.getParameter("confirmPassword");

        String sessionOtp = (String) session.getAttribute("reset_otp");
        String email = (String) session.getAttribute("reset_email");

        Map<String, String> errors = new HashMap<>();
        if (ValidationUtil.isBlank(inputOtp)) {
            errors.put("otp", "Vui lòng nhập mã OTP");
        } else if (!ValidationUtil.isValidOtp(inputOtp)) {
            errors.put("otp", "Mã OTP gồm đúng 6 chữ số");
        } else if (!inputOtp.trim().equals(sessionOtp)) {
            errors.put("otp", "Mã OTP không chính xác!");
        }
        if (ValidationUtil.isBlank(newPassword)) {
            errors.put("password", "Vui lòng nhập mật khẩu mới");
        } else if (!ValidationUtil.isValidPassword(newPassword)) {
            errors.put("password", "Mật khẩu 6-50 ký tự, không chứa khoảng trắng");
        }
        if (ValidationUtil.isBlank(confirmPassword)) {
            errors.put("confirmPassword", "Vui lòng nhập lại mật khẩu");
        } else if (!confirmPassword.equals(newPassword)) {
            errors.put("confirmPassword", "Mật khẩu nhập lại không khớp");
        }
        if (!errors.isEmpty()) {
            req.setAttribute("errors", errors);
            req.getRequestDispatcher("/views/reset-password.jsp").forward(req, resp);
            return;
        }

        boolean isUpdated = userService.resetPassword(email, newPassword);

        if (isUpdated) {
            session.removeAttribute("reset_otp");
            session.removeAttribute("reset_email");
            resp.sendRedirect(req.getContextPath() + "/login");
        } else {
            req.setAttribute("alert", "Lỗi cập nhật mật khẩu!");
            req.getRequestDispatcher("/views/reset-password.jsp").forward(req, resp);
        }
    }
}