package vn.iotstar.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import vn.iotstar.model.Category;
import vn.iotstar.service.CategoryService;
import vn.iotstar.service.impl.CategoryServiceImpl;
import vn.iotstar.util.ValidationUtil;

@SuppressWarnings("serial")
@WebServlet(urlPatterns = { "/admin/category/edit" })
public class CategoryEditController extends HttpServlet {
    CategoryService cateService = new CategoryServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String idParam = req.getParameter("id");
        Category category = ValidationUtil.isInteger(idParam) ? cateService.findById(Integer.parseInt(idParam.trim())) : null;
        if (category == null) {
            resp.sendRedirect(req.getContextPath() + "/admin/category/list");
            return;
        }
        req.setAttribute("category", category);
        req.getRequestDispatcher("/views/admin/edit-category.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");

        String idParam = req.getParameter("id");
        String catename = ValidationUtil.trim(req.getParameter("catename"));
        String icon = req.getParameter("icon");

        if (!ValidationUtil.isInteger(idParam) || cateService.findById(Integer.parseInt(idParam.trim())) == null) {
            resp.sendRedirect(req.getContextPath() + "/admin/category/list");
            return;
        }
        int id = Integer.parseInt(idParam.trim());

        Map<String, String> errors = new HashMap<>();
        if (catename.isEmpty()) {
            errors.put("catename", "Vui lòng nhập tên danh mục");
        } else if (!ValidationUtil.lengthBetween(catename, 2, 100)) {
            errors.put("catename", "Tên danh mục phải từ 2 đến 100 ký tự");
        } else if (isDuplicateName(catename, id)) {
            errors.put("catename", "Tên danh mục đã tồn tại");
        }

        Category category = new Category();
        category.setCategoryId(id);
        category.setCategoryName(catename);
        category.setImages(icon);
        category.setStatus(1); 

        if (!errors.isEmpty()) {
            req.setAttribute("errors", errors);
            req.setAttribute("category", category);
            req.getRequestDispatcher("/views/admin/edit-category.jsp").forward(req, resp);
            return;
        }
        
        cateService.update(category);
        resp.sendRedirect(req.getContextPath() + "/admin/category/list");
    }

    private boolean isDuplicateName(String name, int excludeId) {
        try {
            for (Category c : cateService.findAll()) {
                if (c.getCategoryId() != excludeId && c.getCategoryName() != null
                        && c.getCategoryName().trim().equalsIgnoreCase(name)) {
                    return true;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}