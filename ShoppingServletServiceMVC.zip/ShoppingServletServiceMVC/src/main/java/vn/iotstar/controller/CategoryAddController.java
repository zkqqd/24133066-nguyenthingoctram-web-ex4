package vn.iotstar.controller;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import vn.iotstar.model.Category;
import vn.iotstar.service.CategoryService;
import vn.iotstar.service.impl.CategoryServiceImpl;
import vn.iotstar.util.ValidationUtil;

@SuppressWarnings("serial")
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024, 
    maxFileSize = 1024 * 1024 * 5, 
    maxRequestSize = 1024 * 1024 * 5 * 5
)
@WebServlet(urlPatterns = { "/admin/category/add" })
public class CategoryAddController extends HttpServlet {
    
    CategoryService cateService = new CategoryServiceImpl();
    
    private static final String UPLOAD_DIRECTORY = "E:\\upload";

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("/views/admin/add-category.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");

        Map<String, String> errors = new HashMap<>();

        Part part = null;
        try {
            part = req.getPart("icon");
        } catch (IllegalStateException e) {
            errors.put("icon", "Ảnh đại diện vượt quá dung lượng cho phép (5 MB)");
        }

        String categoryname = ValidationUtil.trim(req.getParameter("catename"));
        if (categoryname.isEmpty()) {
            errors.put("catename", "Vui lòng nhập tên danh mục");
        } else if (!ValidationUtil.lengthBetween(categoryname, 2, 100)) {
            errors.put("catename", "Tên danh mục phải từ 2 đến 100 ký tự");
        } else if (isDuplicateName(categoryname, -1)) {
            errors.put("catename", "Tên danh mục đã tồn tại");
        }

        if (ValidationUtil.hasFile(part) && !ValidationUtil.hasAllowedExtension(part, ValidationUtil.IMAGE_EXT)) {
            errors.put("icon", "Chỉ chấp nhận ảnh: " + String.join(", ", ValidationUtil.IMAGE_EXT));
        }

        if (!errors.isEmpty()) {
            req.setAttribute("errors", errors);
            req.getRequestDispatcher("/views/admin/add-category.jsp").forward(req, resp);
            return;
        }

        Category category = new Category();
        category.setCategoryName(categoryname); 
        category.setStatus(1); 
        
        String uploadPath = UPLOAD_DIRECTORY;
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) {
            uploadDir.mkdirs();
        }
        
        try {
            if (ValidationUtil.hasFile(part)) {
                String ext = ValidationUtil.extension(ValidationUtil.fileName(part));
                String fname = System.currentTimeMillis() + "." + ext;
                part.write(uploadPath + File.separator + fname);
                category.setImages(fname);
            } else {
                category.setImages("avata.png");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        cateService.insert(category);
        resp.sendRedirect(req.getContextPath() + "/admin/category/list");
    }

    private boolean isDuplicateName(String name, int excludeId) {
        try {
            for (Category c : cateService.findAll()) {
                if (c.getCategoryId() != excludeId && c.getCategoryName() != null
                        && c.getCategoryName().trim().equalsIgnoreCase(name)) {
                    return true;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}