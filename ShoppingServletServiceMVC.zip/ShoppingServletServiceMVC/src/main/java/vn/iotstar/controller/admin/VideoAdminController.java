package vn.iotstar.controller.admin;

import vn.iotstar.model.Video;
import vn.iotstar.service.VideoService;
import vn.iotstar.service.impl.VideoServiceImpl;
import vn.iotstar.util.ValidationUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@WebServlet(urlPatterns = {"/admin/video/insert", "/admin/video/update", "/admin/video/delete"})
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, 
                 maxFileSize = 1024 * 1024 * 10,      
                 maxRequestSize = 1024 * 1024 * 50)   
public class VideoAdminController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    VideoService videoService = new VideoServiceImpl();

    public static final String UPLOAD_DIRECTORY = "D:\\uploads"; 

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        String action = request.getServletPath();
        if (action.equals("/admin/video/insert")) {
            insertVideo(request, response);
        } else if (action.equals("/admin/video/update")) {
            updateVideo(request, response);
        }
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getServletPath();
        if (action.equals("/admin/video/delete")) {
            try {
                videoService.delete(request.getParameter("id"));
            } catch (Exception e) {
                e.printStackTrace();
            }
            response.sendRedirect(request.getContextPath() + "/admin/videos");
        } else if (action.equals("/admin/video/insert")) {
            request.getRequestDispatcher("/views/admin/add-video.jsp").forward(request, response);
        } else {
            response.sendRedirect(request.getContextPath() + "/admin/videos");
        }
    }

    private void insertVideo(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        Map<String, String> errors = new HashMap<>();

        Part part = readPart(request, errors);
        String videoId = ValidationUtil.trim(request.getParameter("videoId"));
        String title = ValidationUtil.trim(request.getParameter("title"));
        String description = ValidationUtil.trim(request.getParameter("description"));

        if (videoId.isEmpty()) {
            errors.put("videoId", "Vui lòng nhập mã video");
        } else if (!ValidationUtil.isValidVideoId(videoId)) {
            errors.put("videoId", "Mã video 3-20 ký tự, chỉ gồm chữ không dấu, số, - và _");
        } else if (videoService.findById(videoId) != null) {
            errors.put("videoId", "Mã video đã tồn tại");
        }
        validateTitleAndDescription(title, description, errors);

        if (!errors.containsKey("poster")) {
            if (!ValidationUtil.hasFile(part)) {
                errors.put("poster", "Vui lòng chọn file video/poster");
            } else if (!ValidationUtil.hasAllowedExtension(part, ValidationUtil.MEDIA_EXT)) {
                errors.put("poster", "Chỉ chấp nhận: " + String.join(", ", ValidationUtil.MEDIA_EXT));
            }
        }

        if (!errors.isEmpty()) {
            request.setAttribute("errors", errors);
            request.getRequestDispatcher("/views/admin/add-video.jsp").forward(request, response);
            return;
        }

        Video video = new Video();
        video.setVideoId(videoId);
        video.setTitle(title);
        video.setDescription(description);
        
        try {
            video.setPoster(saveFile(part));
            videoService.insert(video);
        } catch (Exception e) {
            e.printStackTrace();
        }
        response.sendRedirect(request.getContextPath() + "/admin/videos");
    }

    private void updateVideo(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        Map<String, String> errors = new HashMap<>();

        Part part = readPart(request, errors);
        String videoId = ValidationUtil.trim(request.getParameter("videoId"));
        Video video = videoId.isEmpty() ? null : videoService.findById(videoId);
        if (video == null) {
            response.sendRedirect(request.getContextPath() + "/admin/videos");
            return;
        }

        String title = ValidationUtil.trim(request.getParameter("title"));
        String description = ValidationUtil.trim(request.getParameter("description"));
        validateTitleAndDescription(title, description, errors);

        if (!errors.containsKey("poster") && ValidationUtil.hasFile(part)
                && !ValidationUtil.hasAllowedExtension(part, ValidationUtil.MEDIA_EXT)) {
            errors.put("poster", "Chỉ chấp nhận: " + String.join(", ", ValidationUtil.MEDIA_EXT));
        }

        video.setTitle(title);
        video.setDescription(description);

        if (!errors.isEmpty()) {
            request.setAttribute("errors", errors);
            request.setAttribute("video", video);
            request.getRequestDispatcher("/views/admin/edit-video.jsp").forward(request, response);
            return;
        }

        try {
            if (ValidationUtil.hasFile(part)) {
                video.setPoster(saveFile(part));
            }
            videoService.update(video);
        } catch (Exception e) {
            e.printStackTrace();
        }
        response.sendRedirect(request.getContextPath() + "/admin/videos");
    }

    private void validateTitleAndDescription(String title, String description, Map<String, String> errors) {
        if (title.isEmpty()) {
            errors.put("title", "Vui lòng nhập tiêu đề");
        } else if (!ValidationUtil.lengthBetween(title, 3, 255)) {
            errors.put("title", "Tiêu đề phải từ 3 đến 255 ký tự");
        }
        if (description.length() > 2000) {
            errors.put("description", "Mô tả tối đa 2000 ký tự");
        }
    }

    private Part readPart(HttpServletRequest request, Map<String, String> errors) throws IOException, ServletException {
        try {
            return request.getPart("poster");
        } catch (IllegalStateException e) {
            errors.put("poster", "File vượt quá dung lượng cho phép (10 MB)");
            return null;
        }
    }

    private String saveFile(Part part) throws IOException {
        File uploadDir = new File(UPLOAD_DIRECTORY);
        if (!uploadDir.exists()) uploadDir.mkdirs();
        String fileName = ValidationUtil.fileName(part);
        part.write(UPLOAD_DIRECTORY + File.separator + fileName);
        return fileName;
    }
}