package vn.iotstar.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import vn.iotstar.service.UserService;
import vn.iotstar.service.impl.UserServiceImpl;
import vn.iotstar.util.EmailUtil;
import vn.iotstar.util.ValidationUtil;

@SuppressWarnings("serial")
@WebServlet(urlPatterns = "/register")
public class RegisterController extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        if (session != null && session.getAttribute("account") != null) {
            resp.sendRedirect(req.getContextPath() + "/waiting");
            return;
        }
        req.getRequestDispatcher("/views/register.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        resp.setCharacterEncoding("UTF-8");
        req.setCharacterEncoding("UTF-8");
        
        String username = ValidationUtil.trim(req.getParameter("username"));
        String password = req.getParameter("password");
        String confirmPassword = req.getParameter("confirmPassword");
        String email = ValidationUtil.trim(req.getParameter("email"));
        String fullname = ValidationUtil.trim(req.getParameter("fullname"));
        String phone = ValidationUtil.trim(req.getParameter("phone"));
        
        UserService service = new UserServiceImpl();

        // 1. Validate định dạng dữ liệu
        Map<String, String> errors = new HashMap<>();
        if (username.isEmpty()) {
            errors.put("username", "Vui lòng nhập tài khoản");
        } else if (!ValidationUtil.isValidUsername(username)) {
            errors.put("username", "Tài khoản 4-30 ký tự, chỉ gồm chữ không dấu, số, dấu _");
        }
        if (ValidationUtil.isBlank(password)) {
            errors.put("password", "Vui lòng nhập mật khẩu");
        } else if (!ValidationUtil.isValidPassword(password)) {
            errors.put("password", "Mật khẩu 6-50 ký tự, không chứa khoảng trắng");
        }
        if (ValidationUtil.isBlank(confirmPassword)) {
            errors.put("confirmPassword", "Vui lòng nhập lại mật khẩu");
        } else if (!confirmPassword.equals(password)) {
            errors.put("confirmPassword", "Mật khẩu nhập lại không khớp");
        }
        if (fullname.isEmpty()) {
            errors.put("fullname", "Vui lòng nhập họ tên");
        } else if (!ValidationUtil.isValidFullname(fullname)) {
            errors.put("fullname", "Họ tên 2-50 ký tự, chỉ gồm chữ cái và khoảng trắng");
        }
        if (email.isEmpty()) {
            errors.put("email", "Vui lòng nhập email");
        } else if (!ValidationUtil.isValidEmail(email)) {
            errors.put("email", "Email không đúng định dạng");
        }
        if (phone.isEmpty()) {
            errors.put("phone", "Vui lòng nhập số điện thoại");
        } else if (!ValidationUtil.isValidPhone(phone)) {
            errors.put("phone", "Số điện thoại gồm 10 số, bắt đầu bằng 0 (hoặc +84)");
        }

        // 2. Validate trùng lặp trong CSDL
        if (!errors.containsKey("email") && service.checkExistEmail(email)) {
            errors.put("email", "Email đã tồn tại!");
        }
        if (!errors.containsKey("username") && service.checkExistUsername(username)) {
            errors.put("username", "Tài khoản đã tồn tại!");
        }

        if (!errors.isEmpty()) {
            req.setAttribute("errors", errors);
            req.getRequestDispatcher("/views/register.jsp").forward(req, resp);
            return;
        }

        Random rnd = new Random();
        String otp = String.format("%06d", rnd.nextInt(999999));

        boolean isSent = EmailUtil.sendEmail(email, "Xác thực tài khoản", "Mã OTP của bạn là: " + otp);
        
        if (isSent) {
            HttpSession session = req.getSession();
            session.setAttribute("otp", otp);
            session.setAttribute("reg_username", username);
            session.setAttribute("reg_password", password);
            session.setAttribute("reg_email", email);
            session.setAttribute("reg_fullname", fullname);
            session.setAttribute("reg_phone", phone);
            
            resp.sendRedirect(req.getContextPath() + "/verify-otp");
        } else {
            req.setAttribute("alert", "Lỗi gửi email xác thực!");
            req.getRequestDispatcher("/views/register.jsp").forward(req, resp);
        }
    }
}